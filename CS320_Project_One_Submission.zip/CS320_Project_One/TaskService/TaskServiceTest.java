import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void testAddTaskWithUniqueId() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");

        service.addTask(task);

        assertEquals(1, service.getTaskCount());
        assertEquals(task, service.getTask("T123"));
    }

    @Test
    void testCannotAddNullTask() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    void testCannotAddDuplicateTaskId() {
        Task firstTask = new Task("T123", "Call client", "Confirm appointment details");
        Task duplicateTask = new Task("T123", "Send email", "Send documents");

        service.addTask(firstTask);

        assertThrows(IllegalArgumentException.class, () -> service.addTask(duplicateTask));
    }

    @Test
    void testDeleteTaskById() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");
        service.addTask(task);

        service.deleteTask("T123");

        assertEquals(0, service.getTaskCount());
        assertThrows(IllegalArgumentException.class, () -> service.getTask("T123"));
    }

    @Test
    void testDeleteUnknownTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("BADID"));
    }

    @Test
    void testUpdateTaskFields() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");
        service.addTask(task);

        service.updateName("T123", "Send email");
        service.updateDescription("T123", "Send documents to the client");

        Task updatedTask = service.getTask("T123");
        assertEquals("Send email", updatedTask.getName());
        assertEquals("Send documents to the client", updatedTask.getDescription());
    }

    @Test
    void testUpdateUnknownTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("BADID", "Send email"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("BADID", "Send documents"));
    }

    @Test
    void testUpdateWithInvalidValuesThrowsException() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");
        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> service.updateName("T123", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("T123", "123456789012345678901"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("T123", null));
        assertThrows(IllegalArgumentException.class,
                () -> service.updateDescription("T123", "123456789012345678901234567890123456789012345678901"));
    }
}
