import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testTaskCreatedWithValidFields() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");

        assertEquals("T123", task.getTaskId());
        assertEquals("Call client", task.getName());
        assertEquals("Confirm appointment details", task.getDescription());
    }

    @Test
    void testTaskIdCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Call client", "Confirm appointment details"));
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345678901", "Call client", "Confirm appointment details"));
    }

    @Test
    void testNameCannotBeNullOrLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("T123", null, "Confirm appointment details"));
        assertThrows(IllegalArgumentException.class,
                () -> new Task("T123", "123456789012345678901", "Confirm appointment details"));
    }

    @Test
    void testDescriptionCannotBeNullOrLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("T123", "Call client", null));
        assertThrows(IllegalArgumentException.class,
                () -> new Task("T123", "Call client", "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testUpdatableFieldsCanBeChangedWithValidValues() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");

        task.setName("Send email");
        task.setDescription("Send documents to the client");

        assertEquals("Send email", task.getName());
        assertEquals("Send documents to the client", task.getDescription());
    }

    @Test
    void testUpdatableFieldsRejectInvalidValues() {
        Task task = new Task("T123", "Call client", "Confirm appointment details");

        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("123456789012345678901"));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class,
                () -> task.setDescription("123456789012345678901234567890123456789012345678901"));
    }
}
