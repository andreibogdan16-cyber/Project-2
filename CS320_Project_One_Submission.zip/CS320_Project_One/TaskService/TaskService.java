import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("A task with this ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID was not found.");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        getTask(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getTask(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID was not found.");
        }
        return task;
    }

    public int getTaskCount() {
        return tasks.size();
    }
}
