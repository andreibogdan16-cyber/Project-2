import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddContactWithUniqueId() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");

        service.addContact(contact);

        assertEquals(1, service.getContactCount());
        assertEquals(contact, service.getContact("C123"));
    }

    @Test
    void testCannotAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    @Test
    void testCannotAddDuplicateContactId() {
        Contact firstContact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");
        Contact duplicateContact = new Contact("C123", "Alex", "Smith", "7755555678", "456 Oak Ave");

        service.addContact(firstContact);

        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicateContact));
    }

    @Test
    void testDeleteContactById() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");
        service.addContact(contact);

        service.deleteContact("C123");

        assertEquals(0, service.getContactCount());
        assertThrows(IllegalArgumentException.class, () -> service.getContact("C123"));
    }

    @Test
    void testDeleteUnknownContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("BADID"));
    }

    @Test
    void testUpdateContactFields() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");
        service.addContact(contact);

        service.updateFirstName("C123", "Alex");
        service.updateLastName("C123", "Paun");
        service.updatePhone("C123", "7755555678");
        service.updateAddress("C123", "456 Oak Ave");

        Contact updatedContact = service.getContact("C123");
        assertEquals("Alex", updatedContact.getFirstName());
        assertEquals("Paun", updatedContact.getLastName());
        assertEquals("7755555678", updatedContact.getPhone());
        assertEquals("456 Oak Ave", updatedContact.getAddress());
    }

    @Test
    void testUpdateUnknownContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("BADID", "Alex"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("BADID", "Paun"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("BADID", "7755555678"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("BADID", "456 Oak Ave"));
    }

    @Test
    void testUpdateWithInvalidValuesThrowsException() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("C123", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("C123", "MoreThanTen"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("C123", "123"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("C123", "1234567890123456789012345678901"));
    }
}
