import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreatedWithValidFields() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");

        assertEquals("C123", contact.getContactId());
        assertEquals("Andrei", contact.getFirstName());
        assertEquals("Bogdan", contact.getLastName());
        assertEquals("7755551234", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    void testContactIdCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "Andrei", "Bogdan", "7755551234", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "Andrei", "Bogdan", "7755551234", "123 Main St"));
    }

    @Test
    void testFirstNameCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", null, "Bogdan", "7755551234", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "MoreThanTen", "Bogdan", "7755551234", "123 Main St"));
    }

    @Test
    void testLastNameCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", null, "7755551234", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "MoreThanTen", "7755551234", "123 Main St"));
    }

    @Test
    void testPhoneCannotBeNullAndMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", null, "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", "123456789", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", "12345678901", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", "12345ABCDE", "123 Main St"));
    }

    @Test
    void testAddressCannotBeNullOrLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", "7755551234", null));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("C123", "Andrei", "Bogdan", "7755551234", "1234567890123456789012345678901"));
    }

    @Test
    void testUpdatableFieldsCanBeChangedWithValidValues() {
        Contact contact = new Contact("C123", "Andrei", "Bogdan", "7755551234", "123 Main St");

        contact.setFirstName("Alex");
        contact.setLastName("Paun");
        contact.setPhone("7755559876");
        contact.setAddress("456 Oak Ave");

        assertEquals("Alex", contact.getFirstName());
        assertEquals("Paun", contact.getLastName());
        assertEquals("7755559876", contact.getPhone());
        assertEquals("456 Oak Ave", contact.getAddress());
    }
}
