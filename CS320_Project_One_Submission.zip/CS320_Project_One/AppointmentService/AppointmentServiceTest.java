import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    private AppointmentService service;

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L);
    }

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void testAddAppointmentWithUniqueId() {
        Appointment appointment = new Appointment("A123", futureDate(), "Meet with the client");

        service.addAppointment(appointment);

        assertEquals(1, service.getAppointmentCount());
        assertEquals(appointment, service.getAppointment("A123"));
    }

    @Test
    void testCannotAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    void testCannotAddDuplicateAppointmentId() {
        Appointment firstAppointment = new Appointment("A123", futureDate(), "Meet with the client");
        Appointment duplicateAppointment = new Appointment("A123", futureDate(), "Follow-up meeting");

        service.addAppointment(firstAppointment);

        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(duplicateAppointment));
    }

    @Test
    void testDeleteAppointmentById() {
        Appointment appointment = new Appointment("A123", futureDate(), "Meet with the client");
        service.addAppointment(appointment);

        service.deleteAppointment("A123");

        assertEquals(0, service.getAppointmentCount());
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("A123"));
    }

    @Test
    void testDeleteUnknownAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("BADID"));
    }

    @Test
    void testGetUnknownAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("BADID"));
    }
}
