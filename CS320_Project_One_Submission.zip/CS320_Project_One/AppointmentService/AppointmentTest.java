import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L);
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86_400_000L);
    }

    @Test
    void testAppointmentCreatedWithValidFields() {
        Date date = futureDate();
        Appointment appointment = new Appointment("A123", date, "Meet with the client");

        assertEquals("A123", appointment.getAppointmentId());
        assertEquals(date, appointment.getAppointmentDate());
        assertEquals("Meet with the client", appointment.getDescription());
    }

    @Test
    void testAppointmentIdCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, futureDate(), "Meet with the client"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", futureDate(), "Meet with the client"));
    }

    @Test
    void testAppointmentDateCannotBeNullOrInPast() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", null, "Meet with the client"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", pastDate(), "Meet with the client"));
    }

    @Test
    void testDescriptionCannotBeNullOrLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", futureDate(), null));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", futureDate(), "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testAppointmentDateIsDefensivelyCopied() {
        Date originalDate = futureDate();
        Appointment appointment = new Appointment("A123", originalDate, "Meet with the client");

        originalDate.setTime(System.currentTimeMillis() - 86_400_000L);

        assertTrue(appointment.getAppointmentDate().after(new Date()));
    }

    @Test
    void testReturnedAppointmentDateCannotModifyInternalDate() {
        Appointment appointment = new Appointment("A123", futureDate(), "Meet with the client");
        Date returnedDate = appointment.getAppointmentDate();

        returnedDate.setTime(System.currentTimeMillis() - 86_400_000L);

        assertTrue(appointment.getAppointmentDate().after(new Date()));
    }
}
