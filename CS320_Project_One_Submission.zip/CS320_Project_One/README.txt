CS 320 Project One Submission

This ZIP contains the requested ContactService, TaskService, and AppointmentService Java files.
Each service folder contains the object class, service class, object unit test class, and service unit test class.

Folders and files:

ContactService
- Contact.java
- ContactService.java
- ContactTest.java
- ContactServiceTest.java

TaskService
- Task.java
- TaskService.java
- TaskTest.java
- TaskServiceTest.java

AppointmentService
- Appointment.java
- AppointmentService.java
- AppointmentTest.java
- AppointmentServiceTest.java

Testing framework: JUnit 5.
The implementation uses in-memory HashMap collections and validates the field constraints listed in the assignment rubric.
