import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @Test
    public void testAppointmentCreatedSuccessfully() {
        Date date = futureDate();
        Appointment appointment = new Appointment("APT123", date, "Dental appointment");

        assertEquals("APT123", appointment.getAppointmentId());
        assertEquals(date, appointment.getAppointmentDate());
        assertEquals("Dental appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate(), "Valid description");
        });
    }

    @Test
    public void testAppointmentIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT12345678", futureDate(), "Valid description");
        });
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT123", null, "Valid description");
        });
    }

    @Test
    public void testAppointmentDateCannotBeInThePast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT123", pastDate(), "Valid description");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT123", futureDate(), null);
        });
    }

    @Test
    public void testDescriptionCannotBeLongerThanFiftyCharacters() {
        String longDescription = "This description is longer than fifty characters total.";

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT123", futureDate(), longDescription);
        });
    }

    @Test
    public void testAppointmentDateIsDefensivelyCopied() {
        Date originalDate = futureDate();
        Appointment appointment = new Appointment("APT123", originalDate, "Valid description");

        originalDate.setTime(System.currentTimeMillis() - 86400000);

        assertFalse(appointment.getAppointmentDate().before(new Date()));
        assertNotNull(appointment.getAppointmentDate());
    }
}
