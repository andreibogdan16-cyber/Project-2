import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @Test
    public void testAddAppointmentSuccessfully() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("APT123", futureDate(), "Dental appointment");

        service.addAppointment(appointment);

        assertEquals(1, service.getAppointmentCount());
        assertNotNull(service.getAppointment("APT123"));
        assertEquals("Dental appointment", service.getAppointment("APT123").getDescription());
    }

    @Test
    public void testAddAppointmentRejectsNullAppointment() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    public void testAddAppointmentRequiresUniqueAppointmentId() {
        AppointmentService service = new AppointmentService();
        Appointment appointmentOne = new Appointment("APT123", futureDate(), "First appointment");
        Appointment appointmentTwo = new Appointment("APT123", futureDate(), "Second appointment");

        service.addAppointment(appointmentOne);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointmentTwo);
        });

        assertEquals(1, service.getAppointmentCount());
    }

    @Test
    public void testDeleteAppointmentSuccessfully() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("APT123", futureDate(), "Dental appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("APT123");

        assertEquals(0, service.getAppointmentCount());
        assertNull(service.getAppointment("APT123"));
    }

    @Test
    public void testDeleteAppointmentRejectsNullId() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(null);
        });
    }

    @Test
    public void testDeleteAppointmentRejectsMissingId() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("BADID");
        });
    }
}
