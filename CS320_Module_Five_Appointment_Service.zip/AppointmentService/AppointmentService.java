import java.util.HashMap;
import java.util.Map;

/**
 * In-memory appointment service.
 *
 * Requirements implemented:
 * - Add appointments only when the appointment ID is unique.
 * - Delete appointments by appointment ID.
 */
public class AppointmentService {
    private final Map<String, Appointment> appointments;

    public AppointmentService() {
        appointments = new HashMap<>();
    }

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        String appointmentId = appointment.getAppointmentId();
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }

        appointments.put(appointmentId, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist.");
        }

        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    public int getAppointmentCount() {
        return appointments.size();
    }
}
